interface Person {
    name: string;
    age: number;
}

let person = {} as Person;

person.name = "Saad";
person.age = 21;

console.log("Person Name:", person.name);
console.log("Person Age:", person.age);