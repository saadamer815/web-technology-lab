class ClassName {
    ali: string;
    "23": number;

    constructor(param1: string, param2: number) {
        this.ali = param1;
        this["23"] = param2;
    }

    methodName(): void {
        console.log(this.ali, this["23"]);
    }
}

const obj = new ClassName("Ali", 23);
obj.methodName(); 