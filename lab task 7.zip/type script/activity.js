var ClassName = /** @class */ (function () {
    function ClassName(param1, param2) {
        this.ali = param1;
        this["23"] = param2;
    }
    ClassName.prototype.methodName = function () {
        console.log(this.ali, this["23"]);
    };
    return ClassName;
}());
var obj = new ClassName("Ali", 23);
obj.methodName();
