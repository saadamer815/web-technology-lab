// Task 2: Arrow Function for Rectangle Area

let rectangleArea = (length: number, width: number): number => {
    return length * width;
};

let area = rectangleArea(6, 9
);

console.log("Rectangle Area:", area);