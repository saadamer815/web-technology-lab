// Task 2: Arrow Function for Rectangle Area
var rectangleArea = function (length, width) {
    return length * width;
};
var area = rectangleArea(6, 9);
console.log("Rectangle Area:", area);
