const http = require('http');

const server = http.createServer((req, res) => {

    if (req.url === '/home') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end("Welcome to Home Page");
    } 
    else if (req.url === '/about') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end("Welcome to About Page");
    } 
    else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end("Page Not Found");
    }

});

server.listen(3021, () => {
    console.log("Server running on port 3021");
});