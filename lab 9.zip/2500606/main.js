const calcu = require('./calcu');

console.log(calcu.sub(10, 5));
console.log(calcu.mul(4, 3));