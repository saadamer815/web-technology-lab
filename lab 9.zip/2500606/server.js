const http = require('http');

const server = http.createServer((req, res) => {
    res.write("Server is running");
    res.end();
});

server.listen(30000, () => {
    console.log("Server running at http://localhost:30000");
});