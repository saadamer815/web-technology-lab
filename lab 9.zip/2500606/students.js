const fs = require('fs');

fs.writeFileSync('student.txt', 'Name: saad\nCourse: ADCS');

const data = fs.readFileSync('student.txt', 'utf8');
console.log(data);