const http = require('http');

const server = http.createServer((req, res) => {
    if (req.url === '/api') {
        const student = {
            name: "saad",
            course: "BSCS"
        };
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(student));
    } else {
        res.write("Welcome to Node.js API Server");
        res.end();
    }
});

server.listen(3111, () => {
    console.log("Server running at http://localhost:3111");
});